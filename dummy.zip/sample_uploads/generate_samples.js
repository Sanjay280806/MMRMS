import * as XLSX from 'xlsx';
import fs from 'fs';
import path from 'path';

const outDir = path.resolve('sample_uploads');
if (!fs.existsSync(outDir)) {
  fs.mkdirSync(outDir, { recursive: true });
}

// 1. Generate Sample Student Master Excel (.xlsx)
const masterData = [
  {
    'Roll Number': '24BCS041',
    'Student Name': 'DHANUSH R',
    'Department': 'Computer Science and Engineering',
    'Programme': 'B.E. Computer Science and Engineering',
    'Year': 3,
    'Section': '2024 BCS',
    'Mentor Email': 'bharathi.priya@kct.ac.in',
    'CGPA': 8.6,
    'Attendance %': 89,
    'Standing Arrears': 0,
    'Date of Birth': '10 Apr 2006',
    'Student Email': 'dhanush.r@kct.ac.in',
    'Mobile Number': '+91 98420 11223',
  },
  {
    'Roll Number': '24BCS042',
    'Student Name': 'DHARANI S',
    'Department': 'Computer Science and Engineering',
    'Programme': 'B.E. Computer Science and Engineering',
    'Year': 3,
    'Section': '2024 BCS',
    'Mentor Email': 'bharathi.priya@kct.ac.in',
    'CGPA': 7.9,
    'Attendance %': 82,
    'Standing Arrears': 0,
    'Date of Birth': '18 Sep 2006',
    'Student Email': 'dharani.s@kct.ac.in',
    'Mobile Number': '+91 98420 22334',
  },
  {
    'Roll Number': '24BCS043',
    'Student Name': 'DINESH KUMAR M',
    'Department': 'Computer Science and Engineering',
    'Programme': 'B.E. Computer Science and Engineering',
    'Year': 3,
    'Section': '2024 BCS',
    'Mentor Email': 'asmitha.shree@kct.ac.in',
    'CGPA': 6.7,
    'Attendance %': 69,
    'Standing Arrears': 1,
    'Date of Birth': '02 Feb 2006',
    'Student Email': 'dinesh.kumar@kct.ac.in',
    'Mobile Number': '+91 98420 33445',
  },
  {
    'Roll Number': '24BCS044',
    'Student Name': 'DIVYA BHARATHI K',
    'Department': 'Computer Science and Engineering',
    'Programme': 'B.E. Computer Science and Engineering',
    'Year': 3,
    'Section': '2024 BCS',
    'Mentor Email': 'asmitha.shree@kct.ac.in',
    'CGPA': 8.8,
    'Attendance %': 94,
    'Standing Arrears': 0,
    'Date of Birth': '25 Dec 2006',
    'Student Email': 'divya.bharathi@kct.ac.in',
    'Mobile Number': '+91 98420 44556',
  },
];

const wbMaster = XLSX.utils.book_new();
const wsMaster = XLSX.utils.json_to_sheet(masterData);
XLSX.utils.book_append_sheet(wbMaster, wsMaster, 'Students');
XLSX.writeFile(wbMaster, path.join(outDir, 'sample_2024_bcs_students.xlsx'));

// 2. Generate Sample Attendance Update Excel (.xlsx)
const attendanceData = [
  {
    'Roll Number': '24BCS001',
    'Student Name': 'ABHINAV DINESH',
    'Attendance %': 92,
    'CGPA': 8.5,
    'Standing Arrears': 0,
  },
  {
    'Roll Number': '24BCS004',
    'Student Name': 'ABINETHRA G S',
    'Attendance %': 78,
    'CGPA': 7.3,
    'Standing Arrears': 0,
  },
  {
    'Roll Number': '24BCS006',
    'Student Name': 'ABISHAI JARON I',
    'Attendance %': 65,
    'CGPA': 6.8,
    'Standing Arrears': 2,
  },
];

const wbAtt = XLSX.utils.book_new();
const wsAtt = XLSX.utils.json_to_sheet(attendanceData);
XLSX.utils.book_append_sheet(wbAtt, wsAtt, 'Attendance_Update');
XLSX.writeFile(wbAtt, path.join(outDir, 'sample_attendance_update.xlsx'));

console.log('Sample files generated successfully in', outDir);
