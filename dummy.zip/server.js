import fs from 'node:fs';

if (fs.existsSync('.env')) {
  try {
    process.loadEnvFile('.env');
  } catch (err) {
    // env file loading error can be safely ignored
  }
}

import { createApp } from './backend/src/app.js';

const app = createApp();
const port = 3000;

app.listen(port, '0.0.0.0', () => {
  console.log(`MMRMS server running on http://0.0.0.0:${port}`);
});

export default app;
